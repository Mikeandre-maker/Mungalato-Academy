# Venture Arena — interactive prototype

A responsive Next.js browser prototype for an African entrepreneurship simulation and AI-powered Investment Den.

## What's included

- Founder dashboard and editable venture profile
- Six-period food distribution business simulation using fictional Zambian kwacha
- Pricing, stock, marketing, delivery and customer-credit decisions
- Five selectable AI judge personas
- Server-side AI judging API route
- Pitch feedback and provisional scorecard
- Mobile-responsive dark navy / gold interface

## Important prototype limits

- This is a prototype, not a production investment platform.
- Business simulation rules are intentionally simplified and must be calibrated before educational or commercial use.
- The prototype does not persist player accounts or progress to a database yet.
- The included in-memory rate limit is only a basic development safeguard. It resets when the server restarts and is not shared across hosting instances.
- The browser sends the user's selected judge and business context to the server. The API validates and length-limits the request, but production should add authentication, persistent per-user quotas, stronger schema validation, monitoring and abuse controls.
- AI scores are practice feedback only, not a validated prediction of startup success or investment readiness.
- No actual investments, investor matching, equity transfers or funding promises are offered.

## Requirements

- Node.js 20 or later
- An OpenAI API key with API access and billing configured
- npm

## Run locally

1. Extract the ZIP.
2. Open a terminal in the `venture-arena` folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env.local`.
5. Put your secret API key in `.env.local`:

   ```env
   OPENAI_API_KEY=your_secret_key
   OPENAI_MODEL=gpt-4.1-mini
   JUDGE_RATE_LIMIT_PER_HOUR=12
   ```

   Use a model available to your API account. Keep the key server-side; never add it to frontend code or a variable starting with `NEXT_PUBLIC_`.

6. Start the development server:

   ```bash
   npm run dev
   ```

7. Open `http://localhost:3000`.

Without `OPENAI_API_KEY`, the prototype interface and business simulation work, but the live AI judge endpoint returns a configuration error.

## Deploy to Vercel

1. Create a GitHub repository and upload the contents of this project.
2. Import that repository into Vercel.
3. In Vercel project settings, add `OPENAI_API_KEY`, `OPENAI_MODEL`, and `JUDGE_RATE_LIMIT_PER_HOUR` as server-side environment variables.
4. Deploy. Do not commit `.env.local` or any real API key.
5. Test `/api/judge` through the Investment Den after deployment.

Set environment variables for each environment (Preview and Production) as needed. Rotate the API key immediately if it is ever exposed.

## Deploy to GitHub

GitHub stores the source code; it does not run a Next.js server API by itself. Use GitHub Pages only for static sites. Because this prototype uses `/api/judge` and a private server-side API key, deploy it to a server-capable host such as Vercel or another compatible Node.js host.

## Before a public launch

- Add Supabase/PostgreSQL persistence and authentication.
- Replace in-memory rate limiting with a shared store such as Redis/Upstash or an equivalent service.
- Add per-user and per-IP quotas, CAPTCHA or bot protection as appropriate, spend alerts and maximum API usage budgets.
- Validate input using a schema library and limit request body size at the hosting layer.
- Add a deterministic, tested simulation engine with versioned scenario parameters.
- Add privacy policy, terms, age-appropriate safeguards and clear AI disclosures.
- Add moderation/reporting and monitoring.
- Conduct security, financial-logic, accessibility and mobile-browser tests.
- Build the real-investor arena only after legal, consent and verification requirements are defined.

## Suggested next milestone

Wire up Supabase Auth and PostgreSQL so founder profiles, simulation runs, financial snapshots and judge assessments persist across devices and sessions.
